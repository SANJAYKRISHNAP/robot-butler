from setuptools import setup

package_name = 'robot_butler'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ros',
    maintainer_email='ros@todo.todo',
    description='Robot butler package for the French door café',
    license='MIT',
    entry_points={
        'console_scripts': [
            'robot_butler_node = robot_butler.robot_butler_node:main',
        ],
    },
)

