import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from time import time

# Define states
HOME = 0
KITCHEN = 1
TABLE = 2

class RobotButler(Node):
    def __init__(self):
        super().__init__('robot_butler')
        self.current_state = HOME
        self.order_queue = []
        self.current_order = None
        self.timeout_duration = 10  # Timeout after 10 seconds
        self.start_time = None

        # Create subscribers
        self.order_sub = self.create_subscription(
            String,
            'order_topic',
            self.order_callback,
            10
        )

        self.confirmation_sub = self.create_subscription(
            String,
            'confirmation_topic',
            self.confirmation_callback,
            10
        )

        self.get_logger().info("Robot Butler initialized.")

    def order_callback(self, msg):
        """Handle new orders."""
        table = int(msg.data)
        self.order_queue.append(table)
        if not self.current_order:
            self.start_next_task()

    def confirmation_callback(self, msg):
        """Handle confirmations from the kitchen or table."""
        if self.current_order:
            if msg.data == 'confirmed':
                self.get_logger().info(f"Order for table {self.current_order} confirmed.")
                self.move_to_table(self.current_order)
            elif msg.data == 'cancelled':
                self.get_logger().info(f"Order for table {self.current_order} cancelled.")
                self.return_to_home()

    def start_next_task(self):
        """Start the next task (move to kitchen and then to the table)."""
        if self.order_queue:
            self.current_order = self.order_queue.pop(0)
            self.get_logger().info(f"Starting task for table {self.current_order}.")
            self.move_to_kitchen()

    def move_to_kitchen(self):
        """Move to kitchen to collect the food."""
        self.get_logger().info("Moving to the kitchen.")
        self.current_state = KITCHEN
        self.start_time = time()

        # Simulate a wait time for food (e.g., 5 seconds)
        while time() - self.start_time < 5:
            rclpy.spin_once(self)  # Ensure processing of other events like confirmations
            if time() - self.start_time > self.timeout_duration:
                self.get_logger().info("Timeout reached, returning to home.")
                self.return_to_home()
                return

        # If we reached here, food has been collected
        self.get_logger().info("Food collected. Moving to table.")
        self.move_to_table(self.current_order)

    def move_to_table(self, table_number):
        """Move to the specified table to deliver food."""
        self.get_logger().info(f"Delivering food to table {table_number}.")
        self.current_state = TABLE
        self.start_time = time()

        # Simulate time for delivery (e.g., 3 seconds)
        while time() - self.start_time < 3:
            rclpy.spin_once(self)  # Ensure processing of other events
            if time() - self.start_time > self.timeout_duration:
                self.get_logger().info("Timeout reached, returning to home.")
                self.return_to_home()
                return

        self.get_logger().info(f"Food delivered to table {table_number}.")
        # After delivering, check for next order
        self.return_to_home()

    def return_to_home(self):
        """Return to the home position."""
        self.get_logger().info("Returning to home.")
        self.current_state = HOME
        self.current_order = None

        # Check if there are more orders in the queue
        if self.order_queue:
            self.start_next_task()
        else:
            self.get_logger().info("All orders completed.")
            self.order_queue.clear()

def main(args=None):
    rclpy.init(args=args)
    robot_butler = RobotButler()

    try:
        rclpy.spin(robot_butler)
    except KeyboardInterrupt:
        pass

    robot_butler.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
